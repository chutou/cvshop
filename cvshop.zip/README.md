# cvshop 商城

----------
# 1.使用方法 #
首先电脑需要安装nodejs 环境,然后运行下面三个指令

    npm install
	bower install
	grunt serve
浏览器就会运行: http://localhost:9000,自动打开首页